# Topsis-Chirag-102303003

This is a Python package for **TOPSIS (Technique for Order Preference by Similarity to Ideal Solution)**.

##  Installation
```bash
pip install Topsis-Chirag-102303003


## Usage Example
topsis data.csv "1,1,1,2" "+,+,-,+" output-result.csv
